﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

using TestBackendMega.Models;
using TestBackendMega.Library.Utilities;
using TestBackendMega.Library.Entities;

using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Microsoft.EntityFrameworkCore;
using static TestBackendMega.Library.Entities.tr_bpkbEntity;

namespace TestBackendMega.Library.ControllerApis
{
    [Route("api/[controller]")]
    public class tr_bpkbController : Controller
    {

        public ApplicationDbContext context;
        public tr_bpkbController(ApplicationDbContext _context)
        {
            context = _context;
        }

        // GET: api/<controller>
        [HttpGet]
        [Route("GetList")]
        public ActionResult<List<tr_bpkbEntity.tr_bpkb>> Gets()
        {

            var tr_bpkbList = context.tr_bpkbs.ToList();

            return tr_bpkbList;
        }

        // GET api/<controller>/5
        [HttpGet]
        [Route("GetById={id}")]
        public ActionResult<tr_bpkbEntity.tr_bpkb> Get(long id)
        {
            var tr_bpkb = context.tr_bpkbs.Find(id);

            if (tr_bpkb == null)
            {
                return NotFound();
            }

            return tr_bpkb;
        }


        // POST api/<controller>
        [HttpPost]
        [Route("CreateNew")]
        public void Post([FromBody] tr_bpkbEntity.tr_bpkb tr_bpkb)
        {

            context.Entry(tr_bpkb).State = EntityState.Added;
            context.tr_bpkbs.Add(tr_bpkb);
            context.SaveChanges();

            CreatedAtAction(nameof(tr_bpkb), new { id = tr_bpkb.ID }, tr_bpkb);
        }

        // PUT api/<controller>/5
        [HttpPut]
        [Route("UpdateById={id}")]
        public void Put(long id, [FromBody] tr_bpkbEntity.tr_bpkb tr_bpkb)
        {
            
            if (id != tr_bpkb.ID)
            {
                BadRequest();
                return;
            }

            context.Entry(tr_bpkb).State = EntityState.Modified;
            context.Update(tr_bpkb);
            context.SaveChanges();
        }

        // DELETE api/<controller>/5
        [HttpDelete]
        [Route("DeleteById={id}")]
        public void Delete(long id)
        {

            var tr_bpkb = context.tr_bpkbs.Find(id);

            if (tr_bpkb == null)
            {
                NotFound();
                return;
            }

            context.tr_bpkbs.Remove(tr_bpkb);
            context.SaveChanges();
        }

    }
}
