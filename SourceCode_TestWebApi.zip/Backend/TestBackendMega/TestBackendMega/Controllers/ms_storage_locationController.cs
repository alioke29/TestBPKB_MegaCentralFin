﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

using TestBackendMega.Models;
using TestBackendMega.Library.Utilities;
using TestBackendMega.Library.Entities;

using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Microsoft.EntityFrameworkCore;
using static TestBackendMega.Library.Entities.ms_storage_locationEntity;

namespace TestBackendMega.Library.ControllerApis
{
    [Route("api/[controller]")]
    public class ms_storage_locationController : Controller
    {

        public ApplicationDbContext context;
        public ms_storage_locationController(ApplicationDbContext _context)
        {
            context = _context;
        }

        // GET: api/<controller>
        [HttpGet]
        [Route("GetList")]
        public ActionResult<List<ms_storage_locationEntity.ms_storage_location>> Gets()
        {

            var ms_storage_locationList = context.ms_storage_locations.ToList();

            return ms_storage_locationList;
        }

        // GET api/<controller>/5
        [HttpGet]
        [Route("GetById={id}")]
        public ActionResult<ms_storage_locationEntity.ms_storage_location> Get(long id)
        {
            var ms_storage_location = context.ms_storage_locations.Find(id);

            if (ms_storage_location == null)
            {
                return NotFound();
            }

            return ms_storage_location;
        }


        // POST api/<controller>
        [HttpPost]
        [Route("CreateNew")]
        public void Post([FromBody] ms_storage_locationEntity.ms_storage_location ms_storage_location)
        {

            context.Entry(ms_storage_location).State = EntityState.Added;
            context.ms_storage_locations.Add(ms_storage_location);
            context.SaveChanges();

            CreatedAtAction(nameof(ms_storage_location), new { id = ms_storage_location.ID }, ms_storage_location);
        }

        // PUT api/<controller>/5
        [HttpPut]
        [Route("UpdateById={id}")]
        public void Put(long id, [FromBody] ms_storage_locationEntity.ms_storage_location ms_storage_location)
        {
            
            if (id != ms_storage_location.ID)
            {
                BadRequest();
                return;
            }

            context.Entry(ms_storage_location).State = EntityState.Modified;
            context.Update(ms_storage_location);
            context.SaveChanges();
        }

        // DELETE api/<controller>/5
        [HttpDelete]
        [Route("DeleteById={id}")]
        public void Delete(long id)
        {

            var ms_storage_location = context.ms_storage_locations.Find(id);

            if (ms_storage_location == null)
            {
                NotFound();
                return;
            }

            context.ms_storage_locations.Remove(ms_storage_location);
            context.SaveChanges();
        }

    }
}
