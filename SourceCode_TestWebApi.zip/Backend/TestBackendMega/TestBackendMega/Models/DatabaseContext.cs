﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using TestBackendMega.Models;
using TestBackendMega.Library.Entities;

using Microsoft.EntityFrameworkCore;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace TestBackendMega.Models
{
    public class DatabaseContext : DbContext
    {

        public DatabaseContext(DbContextOptions<DatabaseContext> options)
              : base(options)
        {

        }


        public DbSet<ms_storage_locationEntity.ms_storage_location> ms_storage_locations { get; set; }
        public DbSet<tr_bpkbEntity.tr_bpkb> tr_bpkbs { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<ms_storage_locationEntity.ms_storage_location>().ToTable("ms_storage_location");
            modelBuilder.Entity<tr_bpkbEntity.tr_bpkb>().ToTable("tr_bpkb");

        }

    }
}
