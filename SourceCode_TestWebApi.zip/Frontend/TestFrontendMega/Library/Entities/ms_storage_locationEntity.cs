﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TestFrontendMega.Library.Entities
{
    public class ms_storage_locationEntity
    {

        public class ms_storage_location
        {
            [Key]
            public long ID { get; set; }

            public string location_id { get; set; }

            public string location_name { get; set; }
        }

    }
}
