﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Globalization;
using System.IO;
using TestFrontendMega.Library.Entities;
using TestFrontendMega.Library.Utilities;
using static System.Net.Mime.MediaTypeNames;
using static TestFrontendMega.Library.Entities.ms_storage_locationEntity;

namespace TestFrontendMega.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public tr_bpkbEntity.tr_bpkb tr_bpkbInfo;
        public string baseURL = "https://localhost:7145/";

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {


            return View();
        }
        public IActionResult TrBPKBDetail(string id = "")
        {

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(baseURL);

            // LOKASI
            var textLokasi = client.GetStringAsync("api/ms_storage_location/GetList").Result;
            var resultLokasi = JsonConvert.DeserializeObject<List<ms_storage_locationEntity.ms_storage_location>>(textLokasi);

            ViewData["vdLokasi"] = resultLokasi;

            if (!string.IsNullOrEmpty(id))
            {

                GetTrBPKBDetail(id);

                @ViewData["vdMode"] = "(EDIT)";
            }
            else
            {
                @ViewData["vdMode"] = "(ADD)";
            }

            return View();
        }

        private void GetTrBPKBDetail(string id)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(baseURL);

            // TR BPKB
            var textTrBPKB = client.GetStringAsync("api/tr_bpkb/GetList").Result;
            var resultTrBPKB = JsonConvert.DeserializeObject<List<tr_bpkbEntity.tr_bpkb>>(textTrBPKB);

            int trBPKBId = Convert.ToInt16(id);

            IEnumerable<tr_bpkbEntity.tr_bpkb> listTrBPKB = new List<tr_bpkbEntity.tr_bpkb>();
            listTrBPKB = resultTrBPKB.Where(x => x.ID == trBPKBId).ToList();

            ViewData["vdTrBPKBID"] = listTrBPKB.SingleOrDefault().ID.ToString();
            ViewData["vdTrBPKBAgreeNo"] = listTrBPKB.SingleOrDefault().agreement_number;
            ViewData["vdTrBPKBFacturDate"] = Convert.ToDateTime(listTrBPKB.SingleOrDefault().faktur_date).ToString("MM/dd/yyyy");
            ViewData["vdTrBPKBBranchId"] = listTrBPKB.SingleOrDefault().branch_id;
            ViewData["vdTrBPKBNoPolisi"] = listTrBPKB.SingleOrDefault().police_no;
            ViewData["vdTrBPKBNoBPKB"] = listTrBPKB.SingleOrDefault().bpkb_no;
            ViewData["vdTrBPKBLokasi"] = listTrBPKB.SingleOrDefault().location_id;
            ViewData["vdTrBPKBTanggalBPKBIn"] = Convert.ToDateTime(listTrBPKB.SingleOrDefault().bpkb_date_in).ToString("MM/dd/yyyy");
            ViewData["vdTrBPKBTanggalBPKB"] = Convert.ToDateTime(listTrBPKB.SingleOrDefault().bpkb_date).ToString("MM/dd/yyyy");
            ViewData["vdTrBPKBNoFaktur"] = listTrBPKB.SingleOrDefault().faktur_no;
        }

        public IActionResult GetTrBPKB()
        {

            var data = GetListData();

            return new JsonResult(data);
        }

        private IEnumerable<string[]> GetListData()
        {

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(baseURL);

            // LOKASI
            var textLokasi = client.GetStringAsync("api/ms_storage_location/GetList").Result;
            var resultLokasi = JsonConvert.DeserializeObject<List<ms_storage_locationEntity.ms_storage_location>>(textLokasi);

            IEnumerable<ms_storage_locationEntity.ms_storage_location> listLokasi = null;
            listLokasi = resultLokasi.ToList();

            // TR BPKB
            var textTrBPKB = client.GetStringAsync("api/tr_bpkb/GetList").Result;
            var resultTrBPKB = JsonConvert.DeserializeObject<List<tr_bpkbEntity.tr_bpkb>>(textTrBPKB);

            IEnumerable<tr_bpkbEntity.tr_bpkb> listTrBPKB = null;
            listTrBPKB = resultTrBPKB.ToList();

            int rowNo = 1;

            var displayedData = (from a in listTrBPKB.AsEnumerable()
                                 join b in listLokasi on a.location_id equals b.location_id
                                 orderby a.ID descending
                                 select new string[]
                                 {
                                    a.ID.ToString(),
                                    (rowNo++ - listTrBPKB.Count()).ToString(),
                                    a.agreement_number,
                                    a.bpkb_no,
                                    a.branch_id,
                                    Convert.ToDateTime(a.bpkb_date).ToString("dd-MMM-yyyy"),
                                    a.faktur_no,
                                    Convert.ToDateTime(a.faktur_date).ToString("dd-MMM-yyyy"),
                                    a.location_id + " - " + b.location_name,
                                    a.police_no,
                                    Convert.ToDateTime(a.bpkb_date_in).ToString("dd-MMM-yyyy")

        });


            return displayedData;
        }

        [HttpPost]
        public ActionResult AddEditTrBPKB(string id, string paramAll)
        {

            object result = null;

            try
            {
                string[] iParams;
                iParams = paramAll.Split('~');

                string agreeNo = iParams[0].ToString();

                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(baseURL);

                var text = client.GetStringAsync("api/tr_bpkb/GetList").Result;
                var resultTrBPKB = JsonConvert.DeserializeObject<List<tr_bpkbEntity.tr_bpkb>>(text);

                int countAgreeNo = resultTrBPKB.Where(x => x.agreement_number == agreeNo.Trim()).Count();

                // If data empty
                bool isFieldNull = false;
                for (int x = 0; x < iParams.Count(); x++)
                {
                    if (string.IsNullOrEmpty(iParams[x].ToString()))
                    {
                        isFieldNull = true;
                        break;
                    }
                }

                if (!string.IsNullOrEmpty(id) && id != "0")
                {

                    string agreeNoEdit = resultTrBPKB.Where(x => x.ID == Convert.ToInt16(id)).FirstOrDefault().agreement_number;

                    if (isFieldNull)
                        result = new { error = 1 };
                    else if (agreeNoEdit != agreeNo && countAgreeNo > 0)
                        result = new { error = 2 };
                    else
                    {
                        // Edit tr BPKB
                        tr_bpkbInfo = new tr_bpkbEntity.tr_bpkb();
                        tr_bpkbInfo = GetPopulateData(id, paramAll);

                        var jsonString = JsonConvert.SerializeObject(tr_bpkbInfo);
                        var putTask = client.PutAsync("api/tr_bpkb/UpdateById=" + id, new StringContent(jsonString, System.Text.Encoding.UTF8, "application/json"));
                        putTask.Wait();

                        result = new { error = "Edit" };
                    }
                }
                else
                {
                    if (isFieldNull)
                        result = new { error = 1 };
                    else if (countAgreeNo > 0)
                        result = new { error = 2 };
                    else
                    {
                        // Add  tr BPKB
                        tr_bpkbInfo = new tr_bpkbEntity.tr_bpkb();
                        tr_bpkbInfo = GetPopulateData(id, paramAll);

                        var jsonString = JsonConvert.SerializeObject(tr_bpkbInfo);
                        var putTask = client.PostAsync("api/tr_bpkb/CreateNew", new StringContent(jsonString, System.Text.Encoding.UTF8, "application/json"));
                        putTask.Wait();

                        result = new { error = "Add" };
                    }
                }

            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }

            return Json(result);
        }

        private tr_bpkbEntity.tr_bpkb GetPopulateData(string id, string paramAll)
        {

            string[] iParams;

            iParams = paramAll.Split('~');

            string agreeNo = iParams[0].ToString();
            string facturDate = iParams[1].ToString();
            string branchId = iParams[2].ToString();
            string noPolisi = iParams[3].ToString();
            string noBPKB = iParams[4].ToString();
            string lokasi = iParams[5].ToString();
            string tanggalBPKBIn = iParams[6].ToString();
            string tanggalBPKB = iParams[7].ToString();
            string noFaktur = iParams[8].ToString();

            tr_bpkbInfo = new tr_bpkbEntity.tr_bpkb();

            if (!string.IsNullOrEmpty(id) && id != "0")
                tr_bpkbInfo.ID = Convert.ToInt16(id);

            tr_bpkbInfo.agreement_number = agreeNo;
            tr_bpkbInfo.faktur_date = Convert.ToDateTime(facturDate);
            tr_bpkbInfo.branch_id = branchId;
            tr_bpkbInfo.police_no = noPolisi;
            tr_bpkbInfo.bpkb_no = noBPKB;
            tr_bpkbInfo.location_id = lokasi;
            tr_bpkbInfo.bpkb_date_in = Convert.ToDateTime(tanggalBPKBIn);
            tr_bpkbInfo.bpkb_date = Convert.ToDateTime(tanggalBPKB);
            tr_bpkbInfo.faktur_no = noFaktur;

            return tr_bpkbInfo;
        }

        [HttpGet]
        public ActionResult DeleteTrBPKB(string id = "")
        {
            int trBPKBId = 0;
            object result = null;


            try
            {
                trBPKBId = Convert.ToInt16(id);

                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(baseURL);

                var text = client.GetStringAsync("api/tr_bpkb/GetList").Result;
                var resultTrBPKB = JsonConvert.DeserializeObject<List<tr_bpkbEntity.tr_bpkb>>(text);
                int countTrBPKB = resultTrBPKB.Where(x => x.ID == trBPKBId).Count();

                if (countTrBPKB == 1)
                {

                    var putTask = client.DeleteAsync("api/tr_bpkb/DeleteById=" + id);
                    putTask.Wait();

                    result = new { error = 0 };
                }
                else
                    result = new { error = 1 };

            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }

            return Json(result);
        }



    }
}