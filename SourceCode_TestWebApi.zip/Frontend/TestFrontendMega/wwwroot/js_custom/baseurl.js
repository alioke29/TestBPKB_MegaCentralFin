﻿
function getBaseURL() {

    var baseURL;

    if (location.href.indexOf('localhost') > -1 || location.href.indexOf('') > -1 ||
        location.href.indexOf('') > -1) {

        baseURL = location.protocol + "//" + location.hostname + (location.port && ":" + location.port);
    }   
    else {

        var pathArray = location.pathname.split('/');
        var appName = "/" + pathArray[1];

        // QA dan Production
        if (location.href.indexOf('') > -1 ||
            location.href.indexOf('') > -1)
        {

            if (location.href.indexOf('s://') > -1)
                baseURL = "https://" + location.hostname;
            else
                baseURL = "http://" + location.hostname;

            //alert(baseURL);
        }
        else {

            if (location.href.indexOf('s://') > -1)
                baseURL = "https://" + location.hostname + appName;
            else
                baseURL = "http://" + location.hostname + appName;
        }

    }

    return baseURL;
}

// DYNAMIC BASE URL
//function getBaseURL() {

//    var baseURL;

//    if (location.hostname.indexOf(':') > -1) {

//        baseURL = location.protocol + "//" + location.hostname + (location.port && ":" + location.port);
//    }
//    else {

//        var pathArray = location.pathname.split('/');
//        var appName = "/" + pathArray[1];

//        if (pathArray[1] == '') {

//            if (location.href.indexOf('s://') > -1)
//                baseURL = "https://" + location.hostname;
//            else
//                baseURL = "http://" + location.hostname;
//        }
//        else {

//            if (location.href.indexOf('s://') > -1)
//                baseURL = "https://" + location.hostname + appName;
//            else
//                baseURL = "http://" + location.hostname + appName;
//        }

//    }

//    return baseURL;
//}



function removeElementsFromArray(someArray, filter) {
    var newArray = [];
    for (var index = 0; index < someArray.length; index++) {
        if (filter(someArray[index]) == false) {
            newArray.push(someArray[index]);
        }
    }
    return newArray;
}

function isNullOrUndefined(item) {
    return (item == null || typeof (item) == "undefined");
}


function convertDateMM_DD_YYYY(date) {

    var myDate = new Date(date);

    var day = String(myDate.getDate()).padStart(2, '0');
    var month = String(myDate.getMonth() + 1).padStart(2, '0');
    var year = myDate.getFullYear();

    return month + "/" + day + "/" + year;
}

function convertDateDD_MM_YYYY(date) {

    var myDate = new Date(date);

    var day = String(myDate.getDate()).padStart(2, '0');
    var month = String(myDate.getMonth() + 1).padStart(2, '0'); //January is 0!
    var year = myDate.getFullYear();

    return day + "/" + month + "/" + year;
}

function isValidDateMM_DD_YYYY(s) {

    // Assumes s is "mm/dd/yyyy"
    if (! /^\d\d\/\d\d\/\d\d\d\d$/.test(s)) {
        return false;
    }

    const parts = s.split('/').map((p) => parseInt(p, 10));
    parts[0] -= 1;
    const d = new Date(parts[2], parts[0], parts[1]);

    return d.getMonth() === parts[0] && d.getDate() === parts[1] && d.getFullYear() === parts[2];
}

function isValidDateDD_MM_YYYY(s) {

    // Assumes s is "dd/mm/yyyy"
    var temp = s.split('/');
    var d = new Date(temp[1] + '/' + temp[0] + '/' + temp[2]);
    return (d && (d.getMonth() + 1) == temp[1] && d.getDate() == Number(temp[0]) && d.getFullYear() == Number(temp[2]));

}

function isValidEmail(email) {

    var isValid;

    if (! /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i.test(email))
        isValid = false;
    else
        isValid = true;

    return isValid;
}

function convertNumberToSeparator(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function convertSeparatorToNumber(x) {
    return x.toString().replace(',', '');
}

function getFileExtension(filename) {

    const extension = filename.substring(filename.lastIndexOf('.') + 1, filename.length);
    return '.' + extension;
}
