﻿


function getMessageValidationBorder() {

    var agreeNo = $("#txtAgreeNo").val();
    var facturDate = $("#txtFacturDate").val();
    var branchId = $("#txtBranchId").val();
    var noPolisi = $("#txtNoPolisi").val();
    var noBPKB = $("#txtNoBPKB").val();
    var lokasi = $("#ddlLokasi").val();
    var tanggalBPKBIn = $("#txtTanggalBPKBIn").val();
    var tanggalBPKB = $("#txtTanggalBPKB").val();
    var noFaktur = $("#txtNoFaktur").val();

    if (agreeNo == '') $("#txtAgreeNo").css("border", "1px solid red")
    else $("#txtAgreeNo").css("border", "");

    if (facturDate == '') $("#txtFacturDate").css("border", "1px solid red")
    else $("#txtFacturDate").css("border", "");

    if (branchId == '') $("#txtBranchId").css("border", "1px solid red")
    else $("#txtBranchId").css("border", "");

    if (noPolisi == '') $("#txtNoPolisi").css("border", "1px solid red")
    else $("#txtNoPolisi").css("border", "");

    if (noBPKB == '') $("#txtNoBPKB").css("border", "1px solid red")
    else $("#txtNoBPKB").css("border", "");

    if (lokasi == '') $("#ddlLokasi").css("border", "1px solid red")
    else $("#ddlLokasi").css("border", "");

    if (tanggalBPKBIn == '') $("#txtTanggalBPKBIn").css("border", "1px solid red")
    else $("#txtTanggalBPKBIn").css("border", "");

    if (tanggalBPKB == '') $("#txtTanggalBPKB").css("border", "1px solid red")
    else $("#txtTanggalBPKB").css("border", "");

    if (noFaktur == '') $("#txtNoFaktur").css("border", "1px solid red")
    else $("#txtNoFaktur").css("border", "");
}

function getSave() {

    var id = $("#hdnId").val();

    var agreeNo = $("#txtAgreeNo").val();
    var facturDate = $("#txtFacturDate").val();
    var branchId = $("#txtBranchId").val();
    var noPolisi = $("#txtNoPolisi").val();
    var noBPKB = $("#txtNoBPKB").val();
    var lokasi = $("#ddlLokasi").val();
    var tanggalBPKBIn = $("#txtTanggalBPKBIn").val();
    var tanggalBPKB = $("#txtTanggalBPKB").val();
    var noFaktur = $("#txtNoFaktur").val();

    var paramAll = agreeNo + '~' + facturDate + '~' + branchId + '~' + noPolisi + '~' + 
                   noBPKB + '~' + lokasi + '~' + tanggalBPKBIn + '~' + tanggalBPKB + '~' + 
                   noFaktur; 


    var trBPKBId = '';
    if (id != null)
        trBPKBId = id;
    else
        trBPKBId = '';


    $.ajax({
        url: getBaseURL() + '/Home/AddEditTrBPKB/?id=' + trBPKBId,
        method: 'POST',
        dataType: "json",
        data: {
            paramAll: paramAll
        },
        cache: false,
        success: function (json) {

            if (json.error == '1') {

                getMessageValidationBorder();
                return;
            }
            else if (json.error == '2') {

                alert('Agreement No. has already exist.');
                return;
            }

            if (json.error == 'Edit') {

                alert('Edit transaction bpkb has been saved.');
                getReset();
            }
            else if (json.error == 'Add') {

                alert("Add transaction bpkb has been saved.");
                getReset();
            }

        },
        error: function (json) {
            alert(json);
        }
    });
}

function getDelete(id, roleName) {

    swal({
        title: "Konfirmasi",
        text: "Apakah anda yakin ingin menghapus role ini ?",
        type: "warning",
        showCancelButton: true,
        cancelButtonText: "NO",
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "YES",
        closeOnConfirm: false
    }, function () {

        $("#mask").show();

        $.ajax({
            url: '/Role/DeleteRole/?id=' + id,
            type: 'GET',
            dataType: 'json',
            cache: false,
            success: function (json) {

                $("#mask").hide();

                if (json.error == '1') {

                    swal({
                        title: "Confirmation",
                        text: "Cannnot delete Role Name  = '" + roleName + "', this role is being used.",
                        type: "warning",
                        timer: 3000
                    },
                        function () {
                            return;
                        });
                }
                else if (json.error == '0') {

                    swal({
                        title: "Deleted!",
                        text: "Selected role has been deleted.",
                        type: "success",
                        timer: 3000
                    },
                        function () {
                            getReset();
                        });

                }
            },
            error: function (json) {
                alert(json);
            }
        });


    });
}

function getDelete(id) {


    var ask = confirm('Are you sure want to delete this selected ? ')

    if (ask) {

        $.ajax({
            url: getBaseURL() + '/Home/DeleteTrBPKB/?id=' + id,
            type: 'GET',
            dataType: 'json',
            cache: false,
            success: function (json) {

                $("#mask").hide();

                if (json.error == '0') {

                    alert('Selected Transaction BPKB has been deleted.');

                    getReset();

                }
            },
            error: function (json) {
                alert(json);
            }
        });

    }

    return ask;

}

function getTrBPKBDetail(id) {

    window.location = getBaseURL() + '/Home/TrBPKBDetail/' + id;

}

function getReset() {

    window.location = getBaseURL() + '/Home/Index';
}